

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.Iterator;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

public class SoapClient {

	private String soapServiceHost;
	private String soapServicePage;

	public static void main(String[] args) {

		SoapClient sc = new SoapClient("10.10.0.180",
				"/cgi-bin/fpmate.cgi?devid=local_printer&timeout=10000");

		// SoapClient sc = new SoapClient("83.0.0.78",
		// "/cgi-bin/fpmate.cgi?devid=local_printer&timeout=10000");

		// preparo messaggio xml
		// String msg = "<printerFiscalReceipt>"
		// + "<beginFiscalReceipt operator=\"1\" />"
		// +
		// "<printRecItem operator=\"1\" description=\"PANINO\" quantity=\"1\" unitPrice=\"6,00\" department=\"15\" justification=\"1\" />"
		// + "<printRecSubtotal operator=\"1\" option=\"1\" />"
		// +
		// "<printRecTotal operator=\"1\" description=\"Payment in cash\" payment=\"100,00\" paymentType=\"0\" index=\"0\" justification=\"2\" />"
		// + "<endFiscalReceipt operator=\"1\" />"
		// + "</printerFiscalReceipt>";

		String msg = "<printerFiscalReceipt>"
				+ "<displayText operator=\"1\" data=\"Message on customer display\" />"
				+ "<printRecMessage operator=\"1\" messageType=\"1\" index=\"1\" font=\"1\" message=\"First Additional Header Row Type 1\" />"
				+ "<printRecMessage operator=\"1\" messageType=\"1\" index=\"2\" font=\"1\" message=\"Second Additional Header Row Type 1\" />"
				+ "<beginFiscalReceipt operator=\"1\" />"
				+ "<printRecMessage operator=\"1\" messageType=\"4\" message=\"First Additional Row Type 4\" />"
				+ "<printRecItem operator=\"1\" description=\"PANINO\" quantity=\"1\" unitPrice=\"6,00\" department=\"15\" justification=\"1\" />"
				+ "<printRecMessage operator=\"1\" messageType=\"4\" message=\"Second Additional Row Type 4\" />"
				+ "<printRecItem operator=\"1\" description=\"Selling Item 2 VAT 20%\" quantity=\"1,234\" unitPrice=\"10,00\" department=\"15\" justification=\"1\" />"
				+ "<printRecVoidItem operator=\"1\" description=\"Void selling Item 2\" quantity=\"1,234\" unitPrice=\"10,00\" department=\"15\" justification=\"1\" />"
				+ "<printRecSubtotalAdjustment operator=\"1\" description=\"Discount applied to the subtotal\" adjustmentType=\"1\" amount=\"10,12\" justification=\"2\" />"
				+ "<printRecSubtotal operator=\"1\" option=\"1\" />"
				+ "<printBarCode operator=\"1\" position=\"10\" width=\"2\" height=\"66\" hRIPosition=\"3\" hRIFont=\"C\" codeType=\"CODE39\" code=\"0123456789\" />"
				+ "<printRecTotal operator=\"1\" description=\"Payment in cash\" payment=\"100,00\" paymentType=\"0\" index=\"0\" justification=\"2\" />"
				+ "<endFiscalReceipt operator=\"1\" />"
				+ "<clearText operator=\"1\" />" + "</printerFiscalReceipt>";

		sc.sendSoapMessage2(msg);

	}

	public SoapClient(String l_soapServiceHost, String l_soapServicePage) {
		super();
		setSoapServiceHost(l_soapServiceHost);
		setSoapServicePage(l_soapServicePage);

	}

	public void sendSoapMessage(String xmlMesssage) {

		try {
			// String theServlet = "GetThemes";
			SOAPConnectionFactory scf = SOAPConnectionFactory.newInstance();
			SOAPConnection con = scf.createConnection();
			MessageFactory mf = MessageFactory.newInstance();
			SOAPMessage msg = mf.createMessage();
			// Access the SOAPBody object
			SOAPPart part = msg.getSOAPPart();
			SOAPEnvelope envelope = part.getEnvelope();
			SOAPBody body = envelope.getBody();
			// Create SOAPBodyElement request
			Name printerFiscalReceipt = envelope
					.createName("PrinterFiscalReceipt");
			SOAPElement pfrElement = body.addChildElement(printerFiscalReceipt);
			Name displayText = envelope.createName("displayText");
			SOAPElement displaytextElement = pfrElement
					.addChildElement(displayText);
			displaytextElement.addAttribute(envelope.createName("operator"),
					"1");
			displaytextElement.addAttribute(envelope.createName("data"),
					"Testina di vitello");

			// fine
			msg.saveChanges();
			// Create the endpoint and send the message
			URL endpoint = new URL("http://" + getSoapServiceHost()
					+ getSoapServicePage());
			System.out.println("Chiamata a " + getSoapServiceHost()
					+ getSoapServicePage() + " in corso");
			SOAPMessage response = con.call(msg, endpoint);
			System.out.println("Chiamata ok");
			// Get contents of response

			SOAPBody responseBody = response.getSOAPPart().getEnvelope()
					.getBody();
			con.close();
			printResponseBody(responseBody);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public String getSoapServiceHost() {
		return soapServiceHost;
	}

	public void setSoapServiceHost(String soapServiceUrl) {
		this.soapServiceHost = soapServiceUrl;
	}

	private void printResponseBody(SOAPBody responseBody) {
		try {
			System.out.println("--------- RISPOSTA --------------");
			Name attributeName;
			Iterator attIit0 = responseBody.getAllAttributes();
			while (attIit0.hasNext()) {
				attributeName = (Name) attIit0.next();
				System.out.println(attributeName.getLocalName() + ": "
						+ responseBody.getAttributeValue(attributeName));
			}
			Iterator it1 = responseBody.getChildElements();
			while (it1.hasNext()) {
				SOAPBodyElement bodyEl = (SOAPBodyElement) it1.next();
				Iterator attIit1 = bodyEl.getAllAttributes();
				while (attIit1.hasNext()) {
					attributeName = (Name) attIit1.next();
					System.out.println(attributeName.getLocalName() + ": "
							+ bodyEl.getAttributeValue(attributeName));
				}
				Iterator it2 = bodyEl.getChildElements();
				while (it2.hasNext()) {
					SOAPBodyElement bodyEl2 = (SOAPBodyElement) it2.next();
					Iterator attIit2 = bodyEl2.getAllAttributes();
					while (attIit2.hasNext()) {
						attributeName = (Name) attIit2.next();
						System.out.println(attributeName.getLocalName() + ": "
								+ bodyEl2.getAttributeValue(attributeName));
					}
					Iterator it3 = bodyEl2.getChildElements();
					while (it3.hasNext()) {
						SOAPBodyElement bodyEl3 = (SOAPBodyElement) it2.next();
						Iterator attIit3 = bodyEl3.getAllAttributes();
						while (attIit3.hasNext()) {
							attributeName = (Name) attIit3.next();
							System.out.println(attributeName.getLocalName()
									+ ": "
									+ bodyEl3.getAttributeValue(attributeName));
						}
					}
				}
			}
			System.out.println("--------- FINE  RISPOSTA --------------");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public String getSoapServicePage() {
		return soapServicePage;
	}

	public void setSoapServicePage(String soapServicePage) {
		this.soapServicePage = soapServicePage;
	}

	public void sendSoapMessage2(String xmlMesssage) {

		try {
			// String theServlet = "GetThemes";
			SOAPConnectionFactory scf = SOAPConnectionFactory.newInstance();
			SOAPConnection con = scf.createConnection();
			// creating a SOAP Message from StringBuffer to Input Stream to SOAP
			// Msg
			StringBuffer sb1 = new StringBuffer();
			sb1.append("<?xml version='1.0' encoding='utf-8'?>");
			sb1.append("<soap:Envelope xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'>");
			sb1.append("<soap:Body>");
			sb1.append(xmlMesssage);
			sb1.append("</soap:Body>");
			sb1.append("</soap:Envelope>");

			String strSoap = sb1.toString();
			// "strSoap" is the SOAP message i have to send to get a reply.

			byte[] b = strSoap.getBytes("UTF-8");
			InputStream in = new ByteArrayInputStream(b);

			MimeHeaders mh = new MimeHeaders();
			mh.setHeader("Content-Type", "text/xml");

			MessageFactory mf = MessageFactory.newInstance();
			SOAPMessage msg = mf.createMessage(mh, in);

			// fine
			// msg.saveChanges();
			// Create the endpoint and send the message
			URL endpoint = new URL("http://" + getSoapServiceHost()
					+ getSoapServicePage());
			System.out.println("Chiamata a " + getSoapServiceHost()
					+ getSoapServicePage() + " in corso");

			// /////////////////////////////////////////////////////////
			// /////////////////////////////////////////////////////////
			// /////////////////////////////////////////////////////////
			// QUI DA' L'ERRORE
			// com.sun.xml.internal.messaging.saaj.SOAPExceptionImpl: Invalid
			// Content-Type:application/xml. Is this an error message instead of
			// a SOAP response?

			SOAPMessage response = con.call(msg, endpoint);
			con.close();
			// /////////////////////////////////////////////////////////
			// /////////////////////////////////////////////////////////
			// /////////////////////////////////////////////////////////
			// /////////////////////////////////////////////////////////
			System.out.println("Chiamata ok");
			// Get contents of response

			SOAPBody responseBody = response.getSOAPPart().getEnvelope()
					.getBody();
			printResponseBody(responseBody);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}